
import React, { createContext, useState, useContext, ReactNode } from 'react';
import { translations } from '../translations';

type Language = 'en' | 'fr';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string, ...args: any[]) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const storedLang = localStorage.getItem('nextwin-lang');
      // Default to French per user request
      return (storedLang === 'fr' || storedLang === 'en') ? storedLang : 'fr'; 
    } catch {
      return 'fr';
    }
  });

  const setLanguage = (lang: Language) => {
    try {
      localStorage.setItem('nextwin-lang', lang);
    } catch (error) {
      console.error("Could not save language to localStorage", error);
    }
    setLanguageState(lang);
  };

  const t = (key: string, ...args: any[]): string => {
    let translation = translations[language][key] || key;
    if (args.length > 0) {
        args.forEach((arg, index) => {
            translation = translation.replace(`{${index}}`, arg);
        });
    }
    return translation;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
};
