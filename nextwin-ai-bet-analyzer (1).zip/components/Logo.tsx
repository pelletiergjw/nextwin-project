
import React from 'react';

const Logo: React.FC<{ className?: string }> = ({ className = 'h-10' }) => {
  return (
    <div className={`flex items-center ${className}`}>
        <svg width="45" height="45" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="mr-2">
            <defs>
                <linearGradient id="logo-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style={{stopColor: '#F97316'}} />
                    <stop offset="50%" style={{stopColor: '#EC4899'}} />
                    <stop offset="100%" style={{stopColor: '#A855F7'}} />
                </linearGradient>
            </defs>
            <path d="M63.62,13.43,30.29,46.76a4.17,4.17,0,0,0,0,5.9L57.71,80.07a4.17,4.17,0,0,0,5.9,0L84.8,58.88a4.17,4.17,0,0,0,0-5.9L69.52,13.43a4.17,4.17,0,0,0-5.9,0Z" transform="translate(0 0) rotate(45 57.5 46.75)" fill="url(#logo-gradient)" />
            <path d="M47.92,42.08c-8-4.4-15.8-9.1-23.7-13.3a4.17,4.17,0,0,0-5.5,2.1L8.32,49.18a4.17,4.17,0,0,0,2.1,5.5c8,4.4,15.8,9.1,23.7,13.3a4.17,4.17,0,0,0,5.5-2.1l10.4-18.3A4.17,4.17,0,0,0,47.92,42.08Z" fill="url(#logo-gradient)" opacity="0.7"/>
        </svg>
      <span className="text-2xl font-bold text-white">Next<span 
        className="bg-clip-text text-transparent bg-gradient-to-r from-brand-orange via-brand-pink to-brand-purple"
      >Win</span></span>
    </div>
  );
};

export default Logo;
