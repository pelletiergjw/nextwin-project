
import React from 'react';
import { Page } from '../types';
import Button from '../components/Button';
import Card from '../components/Card';
import { ArrowRightIcon, CheckCircleIcon, SparklesIcon, FootballIcon, BasketballIcon, TennisIcon } from '../components/icons';
import { useTranslation } from '../contexts/LanguageContext';

interface HomePageProps {
  navigate: (page: Page) => void;
}

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({ icon, title, description }) => (
    <Card className="text-center transform hover:scale-105 transition-transform duration-300">
        <div className="mx-auto h-12 w-12 flex items-center justify-center rounded-full bg-gradient-to-r from-brand-pink to-brand-purple">
            {icon}
        </div>
        <h3 className="mt-4 text-xl font-bold text-white">{title}</h3>
        <p className="mt-2 text-slate-400">{description}</p>
    </Card>
);

const HomePage: React.FC<HomePageProps> = ({ navigate }) => {
  const { t } = useTranslation();

  return (
    <div className="space-y-24 md:space-y-32 text-center">
      {/* Hero Section */}
      <section>
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-white leading-tight">
          {t('homeTitle1')} <br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-brand-orange via-brand-pink to-brand-purple">
            {t('homeTitle2')}
          </span>
        </h1>
        <p className="mt-6 max-w-2xl mx-auto text-lg md:text-xl text-slate-300">
          {t('homeSubtitle')}
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <Button onClick={() => navigate(Page.Auth)} size="lg">
            {t('homeCTA')} <ArrowRightIcon className="ml-2 h-5 w-5" />
          </Button>
        </div>
        <div className="mt-4 text-sm text-slate-400">{t('homePriceInfo')}</div>
      </section>

      {/* How It Works Section */}
      <section>
        <h2 className="text-3xl md:text-4xl font-bold text-white">{t('homeHowItWorksTitle')}</h2>
        <div className="mt-12 grid md:grid-cols-3 gap-8 text-left">
            <Card>
                <div className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-brand-orange to-brand-pink">01</div>
                <h3 className="mt-2 text-xl font-bold text-white">{t('homeStep1Title')}</h3>
                <p className="mt-2 text-slate-400">{t('homeStep1Desc')}</p>
            </Card>
            <Card>
                <div className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-brand-pink to-brand-purple">02</div>
                <h3 className="mt-2 text-xl font-bold text-white">{t('homeStep2Title')}</h3>
                <p className="mt-2 text-slate-400">{t('homeStep2Desc')}</p>
            </Card>
            <Card>
                <div className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-brand-purple to-brand-orange">03</div>
                <h3 className="mt-2 text-xl font-bold text-white">{t('homeStep3Title')}</h3>
                <p className="mt-2 text-slate-400">{t('homeStep3Desc')}</p>
            </Card>
        </div>
      </section>

      {/* Features Section */}
      <section>
          <h2 className="text-3xl md:text-4xl font-bold text-white">{t('homeFeaturesTitle')}</h2>
          <div className="mt-12 grid md:grid-cols-3 gap-8">
              <FeatureCard 
                  icon={<SparklesIcon className="h-6 w-6 text-white"/>} 
                  title={t('homeFeature1Title')}
                  description={t('homeFeature1Desc')}
              />
              <FeatureCard 
                  icon={<CheckCircleIcon className="h-6 w-6 text-white"/>} 
                  title={t('homeFeature2Title')}
                  description={t('homeFeature2Desc')}
              />
              <FeatureCard 
                  icon={
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-white">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6a7.5 7.5 0 1 0 7.5 7.5h-7.5V6Z" />
                        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 10.5H21A7.5 7.5 0 0 0 13.5 3v7.5Z" />
                    </svg>
                  } 
                  title={t('homeFeature3Title')}
                  description={t('homeFeature3Desc')}
              />
          </div>
      </section>

      {/* Sports & Bets Section */}
      <section>
        <h2 className="text-3xl md:text-4xl font-bold text-white">{t('homeSportsTitle')}</h2>
        <div className="mt-12 grid md:grid-cols-3 gap-8">
            <Card className="text-left">
                <div className="flex items-center">
                    <FootballIcon className="h-8 w-8 text-brand-pink" />
                    <h3 className="ml-4 text-2xl font-bold text-white">{t('homeSportFootball')}</h3>
                </div>
                <p className="mt-4 text-slate-400">{t('homeFootballBets')}</p>
            </Card>
            <Card className="text-left">
                <div className="flex items-center">
                    <BasketballIcon className="h-8 w-8 text-brand-pink" />
                    <h3 className="ml-4 text-2xl font-bold text-white">{t('homeSportBasketball')}</h3>
                </div>
                <p className="mt-4 text-slate-400">{t('homeBasketballBets')}</p>
            </Card>
            <Card className="text-left">
                <div className="flex items-center">
                    <TennisIcon className="h-8 w-8 text-brand-pink" />
                    <h3 className="ml-4 text-2xl font-bold text-white">{t('homeSportTennis')}</h3>
                </div>
                <p className="mt-4 text-slate-400">{t('homeTennisBets')}</p>
            </Card>
        </div>
      </section>

    </div>
  );
};

export default HomePage;
