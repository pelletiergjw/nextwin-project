
export enum Page {
  Home = 'Home',
  Auth = 'Auth',
  Pricing = 'Pricing',
  Faq = 'Faq',
  Dashboard = 'Dashboard',
  Legal = 'Legal',
  Contact = 'Contact',
  Terms = 'Terms',
}

export interface User {
  email: string;
  isSubscribed: boolean;
}

export interface BetSuggestion {
  betType: string;
  odds: string;
  analysisText: string;
  riskLevel: 'Low' | 'Medium' | 'High';
  winProbability: number;
  recommendation: string;
}

export interface AnalysisResult {
  id: string;
  timestamp: string;
  sport: string;
  matchDetails: string;
  suggestions: BetSuggestion[];
}
