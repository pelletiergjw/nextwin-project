
import React, { useState, useEffect, useCallback } from 'react';
import { Page, User, AnalysisResult } from './types';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './views/HomePage';
import AuthPage from './views/AuthPage';
import PricingPage from './views/PricingPage';
import Dashboard from './views/Dashboard';
import FaqPage from './views/FaqPage';
import LegalPage from './views/LegalPage';
import ContactPage from './views/ContactPage';
import TermsPage from './views/TermsPage';
import { LanguageProvider } from './contexts/LanguageContext';

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
};

const AppContent: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [page, setPage] = useState<Page>(Page.Home);
  const [analysisHistory, setAnalysisHistory] = useState<AnalysisResult[]>([]);

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem('nextwin-user');
      const storedHistory = localStorage.getItem('nextwin-history');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
        setPage(Page.Dashboard);
      }
      if (storedHistory) {
        setAnalysisHistory(JSON.parse(storedHistory));
      }
    } catch (error) {
      console.error("Failed to parse from localStorage", error);
      localStorage.removeItem('nextwin-user');
      localStorage.removeItem('nextwin-history');
    }
  }, []);

  const navigate = useCallback((targetPage: Page) => {
    window.scrollTo(0, 0);
    setPage(targetPage);
  }, []);

  const handleLogin = (email: string) => {
    const subscribed = localStorage.getItem('nextwin-subscribed') === 'true';
    const newUser: User = { email, isSubscribed: subscribed };
    setUser(newUser);
    localStorage.setItem('nextwin-user', JSON.stringify(newUser));
    if (!subscribed) {
      navigate(Page.Pricing);
    } else {
      navigate(Page.Dashboard);
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('nextwin-user');
    navigate(Page.Home);
  };

  const handleSubscribe = () => {
    if (user) {
      const updatedUser = { ...user, isSubscribed: true };
      setUser(updatedUser);
      localStorage.setItem('nextwin-user', JSON.stringify(updatedUser));
      localStorage.setItem('nextwin-subscribed', 'true');
      navigate(Page.Dashboard);
    }
  };

  const addAnalysisToHistory = (result: AnalysisResult) => {
    const newHistory = [result, ...analysisHistory];
    setAnalysisHistory(newHistory);
    localStorage.setItem('nextwin-history', JSON.stringify(newHistory));
  };


  const renderPage = () => {
    if (user && user.isSubscribed) {
       switch (page) {
        case Page.Dashboard:
           return <Dashboard user={user} analysisHistory={analysisHistory} addAnalysisToHistory={addAnalysisToHistory} />;
        case Page.Pricing:
           return <PricingPage onSubscribe={handleSubscribe} />;
        case Page.Faq:
            return <FaqPage/>;
        case Page.Legal:
            return <LegalPage/>;
        case Page.Contact:
            return <ContactPage />;
        case Page.Terms:
            return <TermsPage />;
        default:
           return <Dashboard user={user} analysisHistory={analysisHistory} addAnalysisToHistory={addAnalysisToHistory} />;
      }
    }
    
    if (user && !user.isSubscribed) {
        switch (page) {
            case Page.Pricing:
                return <PricingPage onSubscribe={handleSubscribe} />;
            default:
                return <PricingPage onSubscribe={handleSubscribe} />;
        }
    }

    switch (page) {
      case Page.Home:
        return <HomePage navigate={navigate} />;
      case Page.Auth:
        return <AuthPage onLogin={handleLogin} />;
      case Page.Pricing:
        return <PricingPage onSubscribe={() => navigate(Page.Auth)} />;
      case Page.Faq:
        return <FaqPage/>;
      case Page.Legal:
        return <LegalPage/>;
      case Page.Contact:
        return <ContactPage />;
      case Page.Terms:
        return <TermsPage />;
      default:
        return <HomePage navigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans bg-brand-dark">
      <Header user={user} navigate={navigate} onLogout={handleLogout} />
      <main className="flex-grow container mx-auto px-4 py-8 md:py-16">
        {renderPage()}
      </main>
      <Footer navigate={navigate} />
    </div>
  );
};

export default App;
