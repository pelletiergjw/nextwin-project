
import React, { useState } from 'react';
import { useTranslation } from '../contexts/LanguageContext';
import Card from '../components/Card';
import Button from '../components/Button';

const ContactPage: React.FC = () => {
    const { t } = useTranslation();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');
    const [submitted, setSubmitted] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Here you would typically handle the form submission,
        // e.g., send the data to a backend API.
        console.log({ name, email, message });
        setSubmitted(true);
    };

    return (
        <div className="max-w-3xl mx-auto">
            <div className="text-center">
                <h1 className="text-4xl font-bold text-white mb-4">{t('contactTitle')}</h1>
                <p className="text-lg text-slate-300">{t('contactSubtitle')}</p>
            </div>

            <div className="mt-12 grid md:grid-cols-2 gap-12 items-start">
                <Card>
                    {submitted ? (
                        <div className="text-center p-8">
                            <h3 className="text-2xl font-bold text-white">Thank you!</h3>
                            <p className="text-slate-300 mt-2">Your message has been sent successfully. We will get back to you shortly.</p>
                        </div>
                    ) : (
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-slate-300">{t('contactFormName')}</label>
                                <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required className="mt-1 block w-full bg-slate-800 border border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-brand-pink focus:border-brand-pink sm:text-sm" />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-slate-300">{t('contactFormEmail')}</label>
                                <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="mt-1 block w-full bg-slate-800 border border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-brand-pink focus:border-brand-pink sm:text-sm" />
                            </div>
                            <div>
                                <label htmlFor="message" className="block text-sm font-medium text-slate-300">{t('contactFormMessage')}</label>
                                <textarea id="message" value={message} onChange={(e) => setMessage(e.target.value)} required rows={4} className="mt-1 block w-full bg-slate-800 border border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-brand-pink focus:border-brand-pink sm:text-sm"></textarea>
                            </div>
                            <Button type="submit" size="lg" className="w-full">{t('contactFormSubmit')}</Button>
                        </form>
                    )}
                </Card>
                <div className="space-y-4">
                    <h3 className="text-2xl font-bold text-white">{t('contactInfoTitle')}</h3>
                    <div>
                        <h4 className="font-semibold text-brand-pink">{t('contactInfoEmail')}</h4>
                        <a href="mailto:support@nextwin.example.com" className="text-slate-300 hover:text-white">support@nextwin.example.com</a>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ContactPage;
