
import React from 'react';
import { useTranslation } from '../contexts/LanguageContext';
import Card from '../components/Card';

const TermsSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <section>
        <h2 className="text-xl font-bold text-white mb-2">{title}</h2>
        <div className="text-slate-300 space-y-2">
            {children}
        </div>
    </section>
);


const TermsPage: React.FC = () => {
  const { t } = useTranslation();
  return (
    <div className="max-w-3xl mx-auto">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white">{t('termsTitle')}</h1>
        <p className="mt-2 text-sm text-slate-500">{t('termsL1')}</p>
      </div>

      <Card className="mt-8">
        <div className="prose prose-invert max-w-none text-slate-300">
            <p className="lead">{t('termsP1')}</p>
            
            <TermsSection title={t('termsH2')}>
                <p>{t('termsP2')}</p>
            </TermsSection>
            
            <TermsSection title={t('termsH3')}>
                <p>{t('termsP3')}</p>
            </TermsSection>
            
            <TermsSection title={t('termsH4')}>
                <p>{t('termsP4')}</p>
            </TermsSection>

            <TermsSection title={t('termsH5')}>
                <p>{t('termsP5')}</p>
            </TermsSection>

            <TermsSection title={t('termsH6')}>
                <p>{t('termsP6')}</p>
            </TermsSection>
        </div>
      </Card>
    </div>
  );
};

export default TermsPage;
