
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { BetSuggestion } from '../types';

// Assume process.env.API_KEY is available in the environment
const API_KEY = process.env.API_KEY;
if (!API_KEY) {
    console.warn("API_KEY environment variable not set. Using a placeholder.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "YOUR_API_KEY_HERE" });

interface BetDetails {
  sport: string;
  matchDetails: string;
}

export const analyzeBetText = async (betDetails: BetDetails, language: 'fr' | 'en'): Promise<{ suggestions: BetSuggestion[] }> => {
    
  const isFrench = language === 'fr';

  const prompt = isFrench
    ? `Tu es NextWin, un expert IA en analyse de paris sportifs. Pour le match suivant :
- Sport : ${betDetails.sport}
- Match : ${betDetails.matchDetails}

Propose 3 à 5 suggestions de paris pertinents et à haute valeur potentielle. Pour chaque suggestion, fournis :
- Le type de pari (ex: Vainqueur du match, Plus de 2.5 buts, Buteur, etc.).
- Une cote estimée réaliste.
- Une analyse détaillée expliquant ton raisonnement.
- Un niveau de risque ('Low', 'Medium', ou 'High').
- Une probabilité de gain estimée (en pourcentage, ex: 75 pour 75%).
- Une recommandation finale (ex: "Value Bet", "Pari audacieux").

Retourne ta réponse complète sous la forme d'un seul objet JSON valide contenant une clé "suggestions" qui est un tableau de tes propositions. N'inclus aucun texte en dehors de la structure JSON.`
    : `You are NextWin, an expert AI sports betting analyst. For the following match:
- Sport: ${betDetails.sport}
- Match: ${betDetails.matchDetails}

Propose 3 to 5 relevant, high-value bet suggestions. For each suggestion, provide:
- The bet type (e.g., Match Winner, Over 2.5 Goals, Goalscorer, etc.).
- A realistic estimated odds.
- A detailed analysis explaining your reasoning.
- A risk level ('Low', 'Medium', or 'High').
- An estimated win probability (as a number for percentage, e.g., 75 for 75%).
- A final recommendation (e.g., "Value Bet", "Bold Bet").

Return your entire response as a single, valid JSON object containing a "suggestions" key which is an array of your proposals. Do not include any text outside of the JSON structure.`;
  
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    suggestions: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                betType: { type: Type.STRING, description: "The type of bet being suggested." },
                                odds: { type: Type.STRING, description: "The estimated odds for this bet." },
                                analysisText: { type: Type.STRING, description: "A detailed text analysis for the suggestion." },
                                riskLevel: { type: Type.STRING, description: "The assessed risk level.", enum: ['Low', 'Medium', 'High'] },
                                winProbability: { type: Type.INTEGER, description: "The estimated win probability as a percentage (0-100)." },
                                recommendation: { type: Type.STRING, description: "The final recommendation for this specific bet." },
                            },
                            required: ["betType", "odds", "analysisText", "riskLevel", "winProbability", "recommendation"],
                        }
                    }
                },
                required: ["suggestions"],
            },
        },
    });

    const text = response.text;
    if (!text) {
        throw new Error("API returned an empty response.");
    }

    const result = JSON.parse(text.trim());
    
    if (!result.suggestions || !Array.isArray(result.suggestions) || result.suggestions.length === 0) {
        throw new Error("Incomplete analysis data received or no suggestions provided.");
    }
    
    return result as { suggestions: BetSuggestion[] };

  } catch (error) {
    console.error("Error analyzing bet:", error);
    throw new Error("Failed to analyze the match. The AI might be busy or the details could not be processed. Please try again.");
  }
};
