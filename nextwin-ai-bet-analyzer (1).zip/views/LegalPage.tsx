
import React from 'react';
import { useTranslation } from '../contexts/LanguageContext';

const LegalSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <section className="mb-8">
        <h2 className="text-2xl font-bold text-white mb-3 border-b-2 border-brand-pink pb-2">{title}</h2>
        <div className="text-slate-300 space-y-2">
            {children}
        </div>
    </section>
);

const LegalPage: React.FC = () => {
  const { t } = useTranslation();
  return (
    <div className="max-w-3xl mx-auto prose prose-invert">
      <h1 className="text-white text-center text-4xl mb-12">{t('legalTitle')}</h1>
      
      <LegalSection title={t('legalEditorTitle')}>
          <p dangerouslySetInnerHTML={{ __html: t('legalEditorContent') }} />
      </LegalSection>

      <LegalSection title={t('legalDirectorTitle')}>
          <p>{t('legalDirectorContent')}</p>
      </LegalSection>
      
      <LegalSection title={t('legalHostTitle')}>
          <p dangerouslySetInnerHTML={{ __html: t('legalHostContent') }} />
      </LegalSection>

      <LegalSection title={t('legalIPTitle')}>
        <p>{t('legalIPContent')}</p>
      </LegalSection>

      <LegalSection title={t('legalPPTitle')}>
          <p>{t('legalPPBody')}</p>
      </LegalSection>
      
      <LegalSection title={t('legalDisclaimerTitle')}>
          <p>{t('legalDisclaimerBody')}</p>
      </LegalSection>
    </div>
  );
};

export default LegalPage;
