
import React from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import { CheckCircleIcon } from '../components/icons';
import { useTranslation } from '../contexts/LanguageContext';

interface PricingPageProps {
  onSubscribe: () => void;
}

const PricingPage: React.FC<PricingPageProps> = ({ onSubscribe }) => {
  const { t } = useTranslation();

  return (
    <div className="max-w-lg mx-auto text-center">
        <h1 className="text-3xl md:text-4xl font-bold text-white">{t('pricingTitle')}</h1>
        <p className="mt-4 text-lg text-slate-300">
            {t('pricingSubtitle')}
        </p>
        <div className="mt-10">
            <Card className="text-left border-2 border-brand-pink shadow-brand-pink/20">
                <div className="text-center">
                    <h2 className="text-2xl font-bold text-white">{t('pricingPlanName')}</h2>
                    <p className="mt-2 text-slate-400">{t('pricingPlanDesc')}</p>
                    <div className="my-6">
                        <span className="text-5xl font-extrabold text-white">€9,99</span>
                        <span className="text-slate-400"> {t('pricingPricePerMonth')}</span>
                    </div>
                </div>

                <ul className="space-y-4">
                    <li className="flex items-start">
                        <CheckCircleIcon className="h-6 w-6 text-brand-pink mr-3 flex-shrink-0"/>
                        <span className="text-slate-300">{t('pricingFeature1')}</span>
                    </li>
                    <li className="flex items-start">
                        <CheckCircleIcon className="h-6 w-6 text-brand-pink mr-3 flex-shrink-0"/>
                        <span className="text-slate-300">{t('pricingFeature2')}</span>
                    </li>
                    <li className="flex items-start">
                        <CheckCircleIcon className="h-6 w-6 text-brand-pink mr-3 flex-shrink-0"/>
                        <span className="text-slate-300">{t('pricingFeature3')}</span>
                    </li>
                    <li className="flex items-start">
                        <CheckCircleIcon className="h-6 w-6 text-brand-pink mr-3 flex-shrink-0"/>
                        <span className="text-slate-300">{t('pricingFeature4')}</span>
                    </li>
                    <li className="flex items-start">
                        <CheckCircleIcon className="h-6 w-6 text-brand-pink mr-3 flex-shrink-0"/>
                        <span className="text-slate-300">{t('pricingFeature5')}</span>
                    </li>
                     <li className="flex items-start">
                        <CheckCircleIcon className="h-6 w-6 text-brand-pink mr-3 flex-shrink-0"/>
                        <span className="text-slate-300">{t('pricingFeature6')}</span>
                    </li>
                </ul>

                <Button onClick={onSubscribe} size="lg" className="w-full mt-8">
                    {t('pricingCTA')}
                </Button>
            </Card>
        </div>
    </div>
  );
};

export default PricingPage;
