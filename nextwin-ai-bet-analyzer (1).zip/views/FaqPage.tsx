
import React, { useState } from 'react';
import { useTranslation } from '../contexts/LanguageContext';

const FaqItem: React.FC<{ question: string; children: React.ReactNode }> = ({ question, children }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="border-b border-slate-800">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex justify-between items-center text-left py-4"
                aria-expanded={isOpen}
            >
                <span className="text-lg font-medium text-white">{question}</span>
                <svg
                    className={`w-6 h-6 transform transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                </svg>
            </button>
            {isOpen && (
                <div className="pb-4 pr-10 text-slate-300">
                    {children}
                </div>
            )}
        </div>
    );
};


const FaqPage: React.FC = () => {
    const { t } = useTranslation();
    return (
        <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold text-center text-white mb-10">{t('faqTitle')}</h1>
            <div className="space-y-4">
                <FaqItem question={t('faqQ1')}>
                    <p>{t('faqA1')}</p>
                </FaqItem>
                <FaqItem question={t('faqQ2')}>
                    <p>{t('faqA2')}</p>
                </FaqItem>
                <FaqItem question={t('faqQ3')}>
                    <p>{t('faqA3')}</p>
                </FaqItem>
                <FaqItem question={t('faqQ4')}>
                    <p>{t('faqA4')}</p>
                </FaqItem>
                <FaqItem question={t('faqQ5')}>
                    <p>{t('faqA5')}</p>
                </FaqItem>
            </div>
        </div>
    );
}

export default FaqPage;
