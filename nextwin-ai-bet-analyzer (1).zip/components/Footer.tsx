
import React from 'react';
import Logo from './Logo';
import { Page } from '../types';
import { useTranslation } from '../contexts/LanguageContext';

interface FooterProps {
    navigate: (page: Page) => void;
}

const FooterLink: React.FC<{ onClick: () => void; children: React.ReactNode }> = ({ onClick, children }) => (
    <button onClick={onClick} className="text-slate-400 hover:text-white transition-colors duration-200">
        {children}
    </button>
);

const Footer: React.FC<FooterProps> = ({ navigate }) => {
  const { t, language, setLanguage } = useTranslation();

  const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setLanguage(e.target.value as 'en' | 'fr');
  };

  return (
    <footer className="bg-slate-900/50 border-t border-slate-800">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="col-span-2 md:col-span-1">
            <Logo />
            <p className="mt-4 text-slate-400 text-sm">
              AI-Powered Bet Analysis.
            </p>
          </div>
          <div>
            <h3 className="font-bold text-white mb-4">{t('footerProduct')}</h3>
            <ul className="space-y-2">
              <li><FooterLink onClick={() => navigate(Page.Home)}>{t('footerHowItWorks')}</FooterLink></li>
              <li><FooterLink onClick={() => navigate(Page.Pricing)}>{t('headerPricing')}</FooterLink></li>
              <li><FooterLink onClick={() => navigate(Page.Faq)}>{t('headerFAQ')}</FooterLink></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-white mb-4">{t('footerCompany')}</h3>
            <ul className="space-y-2">
                <li><FooterLink onClick={() => navigate(Page.Contact)}>{t('footerContact')}</FooterLink></li>
                <li><FooterLink onClick={() => navigate(Page.Legal)}>{t('footerLegal')}</FooterLink></li>
                <li><FooterLink onClick={() => navigate(Page.Terms)}>{t('footerTerms')}</FooterLink></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-white mb-4">{t('footerLanguage')}</h3>
            <select
              value={language}
              onChange={handleLanguageChange}
              className="bg-slate-800 border border-slate-700 text-white text-sm rounded-lg focus:ring-brand-pink focus:border-brand-pink block w-full p-2.5"
              aria-label={t('footerLanguage')}
            >
                <option value="fr">Français</option>
                <option value="en">English</option>
            </select>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-slate-800 text-center text-slate-500 text-sm">
          <p>&copy; {new Date().getFullYear()} NextWin. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
