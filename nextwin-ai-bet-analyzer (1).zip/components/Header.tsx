
import React from 'react';
import { Page, User } from '../types';
import Logo from './Logo';
import Button from './Button';
import { LogoutIcon } from './icons';
import { useTranslation } from '../contexts/LanguageContext';

interface HeaderProps {
  user: User | null;
  navigate: (page: Page) => void;
  onLogout: () => void;
}

const NavLink: React.FC<{ onClick: () => void; children: React.ReactNode }> = ({ onClick, children }) => (
  <button onClick={onClick} className="text-slate-300 hover:text-white transition-colors duration-200">
    {children}
  </button>
);

const Header: React.FC<HeaderProps> = ({ user, navigate, onLogout }) => {
  const { t } = useTranslation();
  
  return (
    <header className="bg-brand-dark/80 backdrop-blur-sm sticky top-0 z-50 border-b border-slate-800">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <button onClick={() => navigate(user ? Page.Dashboard : Page.Home)}>
            <Logo />
          </button>
          <nav className="hidden md:flex items-center space-x-6">
            {user ? (
              <>
                <NavLink onClick={() => navigate(Page.Dashboard)}>{t('headerDashboard')}</NavLink>
                <NavLink onClick={() => navigate(Page.Pricing)}>{t('headerSubscription')}</NavLink>
                <button onClick={onLogout} className="flex items-center text-slate-300 hover:text-white transition-colors duration-200">
                    <LogoutIcon className="h-5 w-5 mr-1" />
                    {t('headerLogout')}
                </button>
              </>
            ) : (
              <>
                <NavLink onClick={() => navigate(Page.Home)}>{t('headerHome')}</NavLink>
                <NavLink onClick={() => navigate(Page.Pricing)}>{t('headerPricing')}</NavLink>
                <NavLink onClick={() => navigate(Page.Faq)}>{t('headerFAQ')}</NavLink>
                <Button onClick={() => navigate(Page.Auth)} variant="secondary" size="sm">
                  {t('headerLogin')}
                </Button>
                <Button onClick={() => navigate(Page.Auth)} size="sm">
                  {t('headerGetStarted')}
                </Button>
              </>
            )}
          </nav>
          <div className="md:hidden">
            {user ? (
                 <button onClick={onLogout} className="p-2 rounded-md text-slate-300 hover:text-white hover:bg-slate-800" aria-label={t('headerLogout')}>
                    <LogoutIcon className="h-6 w-6" />
                </button>
            ) : (
                <Button onClick={() => navigate(Page.Auth)} size="sm">
                    {t('headerLogin')}
                </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
