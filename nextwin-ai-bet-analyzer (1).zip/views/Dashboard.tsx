
import React, { useState, useCallback, FormEvent } from 'react';
import { User, AnalysisResult, BetSuggestion } from '../types';
import { analyzeBetText } from '../services/geminiService';
import Card from '../components/Card';
import Button from '../components/Button';
import Spinner from '../components/Spinner';
import { SparklesIcon } from '../components/icons';
import { useTranslation } from '../contexts/LanguageContext';

interface DashboardProps {
  user: User;
  analysisHistory: AnalysisResult[];
  addAnalysisToHistory: (result: AnalysisResult) => void;
}

const RiskBadge: React.FC<{ level: 'Low' | 'Medium' | 'High' }> = ({ level }) => {
    const { t } = useTranslation();
    const colorClasses = {
        Low: 'bg-green-500/20 text-green-400 border-green-500',
        Medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500',
        High: 'bg-red-500/20 text-red-400 border-red-500',
    };
    const riskText = {
        Low: t('riskLow'),
        Medium: t('riskMedium'),
        High: t('riskHigh'),
    }
    return (
        <span className={`px-3 py-1 text-sm font-medium rounded-full border ${colorClasses[level]}`}>
            {riskText[level]} {t('riskSuffix')}
        </span>
    );
};

const BetSuggestionCard: React.FC<{ suggestion: BetSuggestion }> = ({ suggestion }) => {
    const { t } = useTranslation();
    return (
        <Card className="bg-slate-800/50 border-slate-700">
            <div className="space-y-4">
                 <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                    <h3 className="text-xl font-bold text-white">{suggestion.betType}</h3>
                    <span className="text-lg font-bold text-brand-purple">{suggestion.odds}</span>
                 </div>
                 <RiskBadge level={suggestion.riskLevel} />
                
                <div>
                    <span className="font-bold text-slate-400">{t('analysisWinProb')}:</span>
                    <div className="w-full bg-slate-700 rounded-full h-4 mt-1">
                        <div
                            className="bg-gradient-to-r from-brand-pink to-brand-purple h-4 rounded-full"
                            style={{ width: `${suggestion.winProbability}%` }}
                            aria-valuenow={suggestion.winProbability}
                            aria-valuemin={0}
                            aria-valuemax={100}
                            role="progressbar"
                        ></div>
                    </div>
                    <p className="text-right font-bold text-white text-lg">{suggestion.winProbability}%</p>
                </div>

                 <div>
                    <h3 className="font-bold text-slate-400">{t('analysisReco')}:</h3>
                    <p className={`text-xl font-bold ${suggestion.recommendation.toLowerCase().includes('value') ? 'text-green-400' : 'text-yellow-400'}`}>
                        {suggestion.recommendation}
                    </p>
                </div>
                
                <div>
                    <h3 className="font-bold text-slate-400">{t('analysisAI')}:</h3>
                    <p className="text-slate-300 whitespace-pre-wrap">{suggestion.analysisText}</p>
                </div>
            </div>
        </Card>
    );
}

const AnalysisResultDisplay: React.FC<{ result: AnalysisResult }> = ({ result }) => {
    return (
        <div className="mt-8 animate-fade-in">
            <h2 className="text-3xl font-bold text-white text-center mb-6">{result.matchDetails}</h2>
            <div className="space-y-6">
                {result.suggestions.map((suggestion, index) => (
                    <BetSuggestionCard key={index} suggestion={suggestion} />
                ))}
            </div>
        </div>
    );
}

const FormInput: React.FC<{id: string, label: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, placeholder?: string, required?: boolean}> = 
  ({ id, label, value, onChange, placeholder, required }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-300">{label}</label>
        <input
            type="text"
            id={id}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            required={required}
            className="mt-1 block w-full bg-slate-800 border border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-brand-pink focus:border-brand-pink sm:text-sm"
        />
    </div>
);

const Dashboard: React.FC<DashboardProps> = ({ user, analysisHistory, addAnalysisToHistory }) => {
  const { t, language } = useTranslation();
  const [activeTab, setActiveTab] = useState<'analysis' | 'history'>('analysis');
  
  const [sport, setSport] = useState('Football');
  const [matchDetails, setMatchDetails] = useState('');

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [currentAnalysisResult, setCurrentAnalysisResult] = useState<AnalysisResult | null>(null);
  
  const handleAnalyze = useCallback(async (e: FormEvent) => {
    e.preventDefault();
    if (!matchDetails) {
      setError(t('dashboardErrorFillFields'));
      return;
    }
    setIsLoading(true);
    setError('');
    setCurrentAnalysisResult(null);
    try {
      const { suggestions } = await analyzeBetText({ sport, matchDetails }, language);
      const newResult: AnalysisResult = {
        id: new Date().toISOString(),
        timestamp: new Date().toLocaleString(),
        sport,
        matchDetails,
        suggestions,
      };
      setCurrentAnalysisResult(newResult);
      addAnalysisToHistory(newResult);
    } catch (e: any) {
      setError(e.message || t('dashboardErrorUnknown'));
    } finally {
      setIsLoading(false);
    }
  }, [sport, matchDetails, language, addAnalysisToHistory, t]);

  return (
    <div>
        <div className="text-center">
            <h1 className="text-3xl font-bold text-white">{t('dashboardWelcome')} {user.email}</h1>
            <p className="text-slate-400 mt-2">{t('dashboardPrompt')}</p>
        </div>
        <div className="flex justify-center border-b border-slate-800 my-8">
            <button onClick={() => setActiveTab('analysis')} className={`px-6 py-3 font-medium ${activeTab === 'analysis' ? 'text-brand-pink border-b-2 border-brand-pink' : 'text-slate-400'}`}>{t('dashboardTabAnalysis')}</button>
            <button onClick={() => setActiveTab('history')} className={`px-6 py-3 font-medium ${activeTab === 'history' ? 'text-brand-pink border-b-2 border-brand-pink' : 'text-slate-400'}`}>{t('dashboardTabHistory')}</button>
        </div>
        
        {activeTab === 'analysis' && (
            <div className="max-w-4xl mx-auto">
                <Card>
                    <form onSubmit={handleAnalyze} className="space-y-4">
                        <div>
                            <label htmlFor="sport" className="block text-sm font-medium text-slate-300">{t('dashboardFormSport')}</label>
                            <select
                                id="sport"
                                value={sport}
                                onChange={(e) => setSport(e.target.value)}
                                className="mt-1 block w-full bg-slate-800 border border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-brand-pink focus:border-brand-pink sm:text-sm"
                            >
                                <option>Football</option>
                                <option>Basketball</option>
                                <option>Tennis</option>
                            </select>
                        </div>
                        
                        <FormInput id="matchDetails" label={t('dashboardFormMatch')} value={matchDetails} onChange={(e) => setMatchDetails(e.target.value)} placeholder={t('dashboardFormMatchPlaceholder')} required />

                        <div className="pt-2">
                             <Button type="submit" disabled={isLoading} size="lg" className="w-full">
                                {isLoading ? <Spinner size="sm" /> : <SparklesIcon className="h-5 w-5 mr-2" />}
                                {isLoading ? t('dashboardAnalyzingButton') : t('dashboardAnalyzeButton')}
                            </Button>
                        </div>
                    </form>
                </Card>
                {error && <p className="text-red-500 text-center mt-4">{error}</p>}
                {currentAnalysisResult && <AnalysisResultDisplay result={currentAnalysisResult}/>}
            </div>
        )}

        {activeTab === 'history' && (
            <div className="space-y-4">
                {analysisHistory.length === 0 ? (
                    <p className="text-center text-slate-400">{t('dashboardHistoryEmpty')}</p>
                ) : (
                    analysisHistory.map(result => <AnalysisResultDisplay key={result.id} result={result} />)
                )}
            </div>
        )}

    </div>
  );
};

export default Dashboard;
