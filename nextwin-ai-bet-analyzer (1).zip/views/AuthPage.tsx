
import React, { useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import { useTranslation } from '../contexts/LanguageContext';

interface AuthPageProps {
  onLogin: (email: string) => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLogin, setIsLogin] = useState(true);
  const { t } = useTranslation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      onLogin(email);
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <Card>
        <h2 className="text-2xl font-bold text-center text-white mb-2">
          {isLogin ? t('authWelcome') : t('authCreateAccount')}
        </h2>
        <p className="text-center text-slate-400 mb-6">
          {isLogin ? t('authLoginPrompt') : t('authSignupPrompt')}
        </p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-slate-300">
              {t('authEmailLabel')}
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="mt-1 block w-full bg-slate-800 border border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-brand-pink focus:border-brand-pink sm:text-sm"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label htmlFor="password"  className="block text-sm font-medium text-slate-300">
              {t('authPasswordLabel')}
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="mt-1 block w-full bg-slate-800 border border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-brand-pink focus:border-brand-pink sm:text-sm"
              placeholder="••••••••"
            />
          </div>
          <Button type="submit" className="w-full" size="lg">
            {isLogin ? t('authLoginButton') : t('authSignupButton')}
          </Button>
        </form>
        <div className="mt-6 text-center">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-sm text-brand-pink hover:text-brand-orange transition"
          >
            {isLogin ? t('authToggleToSignup') : t('authToggleToLogin')}
          </button>
        </div>
      </Card>
    </div>
  );
};

export default AuthPage;
